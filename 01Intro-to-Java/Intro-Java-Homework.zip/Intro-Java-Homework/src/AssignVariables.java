/**
 * Created by Dyno on 20.3.2016 г..
 */
public class AssignVariables {
boolean boolValue = false;
    byte byteNumber = 127;
    char symbol = 'c';
    String address = "Palo Alto, CA";
    int integerNumber = 32767;
    long longNumber = 2000000000;
    float floatNumber = 0.5f;
    double doubleNumber = 0.1234567891011;
    short shortNumber = 32768;
}
