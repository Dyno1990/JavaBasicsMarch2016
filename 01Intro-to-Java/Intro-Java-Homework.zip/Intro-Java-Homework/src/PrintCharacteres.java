/**
 * Created by Dyno on 20.3.2016 г..
 */
public class PrintCharacteres {

    char[] ArrayChars = new char[]{'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't','u','v','w', 'x', 'y','z'};
    int size = ArrayChars.length;
    for(int i=0; i <= size; i++)
    {
        System.out.print(ArrayChars[i] + ' ');
    }

}
